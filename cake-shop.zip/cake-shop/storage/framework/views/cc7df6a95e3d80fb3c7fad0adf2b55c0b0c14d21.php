<?php $__env->startComponent('mail::message'); ?>
<?php echo e($title); ?>


<?php echo e($product); ?><br>
<?php echo e($description); ?>


Obrigado,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /var/www/cake-shop/resources/views/emails/new_product.blade.php ENDPATH**/ ?>